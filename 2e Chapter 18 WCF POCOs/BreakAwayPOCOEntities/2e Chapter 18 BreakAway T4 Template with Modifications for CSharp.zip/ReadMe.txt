Programming Entity Framework 2nd edition

Chapter 18 MOdified T4 Template

In chapter 13, you added a T4 template for the BreakAway model using Microsoft's POCO template.
Then in Chapter 18 you made another modification.

The chapter 18 modification was to have the entities inherit from a newly introduced class called StateObject.

This template is the combination of those changes made in Chatper 13 and Chapter 18.
where there is a MaxLength value defined in the model.

8/20: Currently you will find the C# template only. I will create one for VB as soon as I can.

www.learnentityframework.com