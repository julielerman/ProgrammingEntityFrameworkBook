﻿Namespace Model
  Public Class Hostel
	  Inherits Lodging
	Public Property MaxPersonsPerRoom() As Integer
	Public Property PrivateRoomsAvailable() As Boolean
  End Class
End Namespace