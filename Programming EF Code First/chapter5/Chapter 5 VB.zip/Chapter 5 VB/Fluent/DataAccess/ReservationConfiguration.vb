﻿Imports System.Data.Entity.ModelConfiguration
Imports Model

Namespace DataAccess
  Public Class ReservationConfiguration
	  Inherits EntityTypeConfiguration(Of Reservation)
  End Class
End Namespace
