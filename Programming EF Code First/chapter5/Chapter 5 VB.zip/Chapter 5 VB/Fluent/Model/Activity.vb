﻿Namespace Model
  Public Class Activity
	Public Property ActivityId() As Integer
	Public Property Name() As String
	Public Property Trips() As List(Of Trip)
  End Class
End Namespace