﻿Namespace Model
  Public Class PersonPhoto
	Public Property PersonId() As Integer
	Public Property Photo() As Byte()
	Public Property Caption() As String
	Public Property PhotoOf() As Person
  End Class
End Namespace