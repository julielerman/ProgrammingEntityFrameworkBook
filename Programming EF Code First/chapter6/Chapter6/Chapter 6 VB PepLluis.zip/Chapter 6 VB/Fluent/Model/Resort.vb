﻿Namespace Model
  Public Class Resort
	  Inherits Lodging
	Public Property Entertainment() As String
	Public Property Activities() As String
  End Class
End Namespace
