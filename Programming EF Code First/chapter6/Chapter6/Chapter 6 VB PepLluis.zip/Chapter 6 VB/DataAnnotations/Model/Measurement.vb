﻿Namespace Model
  Public Class Measurement
	Public Property Reading() As Decimal
	Public Property Units() As String
  End Class
End Namespace